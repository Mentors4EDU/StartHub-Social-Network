rtMediaHook.register(
	'rtmedia_js_popup_after_content_added',
	function ( args ) {
		if( typeof rtsocial_init_counters == "function") {
			rtsocial_init_counters();            
		}
                return 1;
	}
);
