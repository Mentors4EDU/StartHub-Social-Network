/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

jQuery( document ).ready( function( $ ) {

    rtMediaHook.register( 'rtmedia_js_popup_after_content_added', function( args ) {
        jQuery( '.rtmedia-like-counter-wrap' ).attr( 'title', rtmedia_like_main_js.rtmedia_media_who_liked );
        return 1;
    } );

    jQuery( 'body' ).on( 'click', '.rtmedia-like-counter-wrap', function( e ) {
        e.preventDefault();

        jQuery( '.rtm-media-likes-wrapper' ).show();
        jQuery( '.rtm-media-likes .loading-gif' ).show();

        $media_id = jQuery( '.current-media-item' ).val();
        
        jQuery.ajax( {
            type: 'POST',
            url: rtmedia_ajax_url,
            data: {
                action: 'rtm_media_likes',
                media_id: $media_id
            },
            success: function( response_data ) {
                jQuery( '.rtm-media-likes .loading-gif' ).hide();

                if( response_data ) {
                    $likes_list = '<ul class="media-like-list">';
                    $likes_list += response_data;
                    $likes_list += '</ul>';
                } else {
                    $likes_list = "<p>" + rtmedia_like_main_js.rtmedia_media_no_likes + "</p>";
                }

                jQuery( '.media-like-list' ).remove();
                jQuery( '.rtm-media-likes' ).append( $likes_list );
            },
            error: function( response_error ) {
                console.log( response_error );
            }
        } );
    } );

    jQuery( document ).keyup( function( e ) {
        if( e.keyCode == 27 || e.keyCode == 37 || e.keyCode == 39 ) {
            jQuery( '.rtm-media-likes-wrapper' ).hide();
            jQuery( '.media-like-list' ).remove();
        }   // esc
    } );

    jQuery( 'body' ).on( 'click', '.rtm-media-likes .close', function() {
        jQuery( '.rtm-media-likes-wrapper' ).hide();
        jQuery( '.media-like-list' ).remove();
    } );

    jQuery( document ).mouseup( function( e ) {
        var container = jQuery( ".rtm-media-likes" );

        if( !container.is( e.target ) && container.has( e.target ).length === 0 ) {
            container.parent().hide();
        }
    } );

    if( jQuery( '.rtmedia-like-counter-wrap' ).length > 0 ) {
        jQuery( '.rtmedia-like-counter-wrap' ).attr( 'title', rtmedia_like_main_js.rtmedia_media_who_liked );
    }

} );