jQuery( document ).ready( function(){
	// edit custom thumbnails
	jQuery('#rtmedia_media_custom_thumbnail').closest('form').attr( "enctype", "multipart/form-data" );
	jQuery('#rtmedia_media_custom_thumbnail').closest('form').attr( "encoding", "multipart/form-data" );
} );