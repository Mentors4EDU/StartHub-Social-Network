package android.support.v4.internal.view;

import android.view.SubMenu;

public interface SupportSubMenu extends SupportMenu, SubMenu {
}
